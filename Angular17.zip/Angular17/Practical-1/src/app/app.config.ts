import { ApplicationConfig, importProvidersFrom } from '@angular/core';
import { provideRouter } from '@angular/router';

import { routes } from './app.routes';
import { provideClientHydration } from '@angular/platform-browser';
import { provideHttpClient } from '@angular/common/http';
import { InMemoryWebApiModule } from 'angular-in-memory-web-api';
import { ProductData } from './products/Data/productData';

export const appConfig: ApplicationConfig = {
  providers: [
    provideHttpClient(), 
    importProvidersFrom(
      InMemoryWebApiModule.forRoot(ProductData,{delay:500})
    ), 
    provideRouter(routes),
    provideClientHydration()
  ]
};
