import { Routes } from '@angular/router';
import { WelcomeComponent } from './home/welcome/welcome.component';
import { PageNotFoundComponent } from './page-not-found.component';

export const routes: Routes = [
   {
        path:'products',
        loadChildren:()=>import('./products/Routes/product.routes')
                        .then(r => r.PRODUCT_ROUTES)
   },
   {
        path:'about',
        loadComponent:()=> import("./about/about.component")
                                .then(c=>c.AboutComponent)
   },
    {
        path:'welcome',
        component:WelcomeComponent
    },
    
    {
        path:'',
        redirectTo:'welcome',
        pathMatch:'full'
    },
    {
        path:'**',
        component:PageNotFoundComponent
    }
];
