import { ResolveFn } from '@angular/router';
import { Observable, catchError, map, of } from 'rxjs';
import { ProductResolved } from '../../Model/productResolver';
import { ProductService } from '../../service/product.service';
import { inject } from '@angular/core';

export const productDetailResolver: ResolveFn<Observable<ProductResolved>> = (route, state) => {
      const id = Number(route.paramMap.get('id'));
      const service:ProductService = inject(ProductService);
      let message:string = '';
   if(isNaN(id)){
        message = 'product id  was not a number';
      return of({product:null,error:message})
   }   
  return service.getProduct(id)
                .pipe(
                  map(product=>({product:product,error:''})),
                  catchError(err=>{
                    message = `Retrived error: ${err.error.message}`;
                    return of({product:null,error:message})
                  })
                );
};
