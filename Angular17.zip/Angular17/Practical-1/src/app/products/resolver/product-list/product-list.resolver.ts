import { ResolveFn } from '@angular/router';
import { ProductService } from '../../service/product.service';
import { inject } from '@angular/core';
import { Observable, catchError, map, of } from 'rxjs';
import { ProductsResolved } from '../../Model/productsResolver';

export const productListResolver: ResolveFn<Observable<ProductsResolved>> = (route, state) => {
    const service:ProductService = inject(ProductService);

    return service.getProducts()
                  .pipe(
                    map(products=>({products:products,error:''})),
                    catchError(err=>{
                          const errorMessage = `retrived error ${err.error.message}`;
                          return of({products:[], error:errorMessage}) 
                    })
                  )


};
