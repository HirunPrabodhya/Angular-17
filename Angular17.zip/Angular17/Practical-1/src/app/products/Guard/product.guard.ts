import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';

export const productGuard: CanActivateFn = (route, state) => {
  const id = Number(route.paramMap.get('id'));
  const router:Router = inject(Router);
  if(isNaN(id) || id < 0){
    if (typeof window !== 'undefined') {
      
          alert("id is not a number");
    }
    
    router.navigate(['/products']);
    return false;
  }
  return true;
};
