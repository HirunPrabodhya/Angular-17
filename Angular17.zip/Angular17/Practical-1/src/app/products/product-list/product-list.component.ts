import { CommonModule} from '@angular/common';
import { Component, OnDestroy, OnInit, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IProduct } from '../Model/product';
import { ConvertToSpacePipe } from '../../Shared/convert-to-space.pipe';
import { StarComponent } from '../../Shared/star/star.component';
import { ProductService } from '../service/product.service';
import { Subscription } from 'rxjs';
import { ActivatedRoute, RouterLink } from '@angular/router';


@Component({
  selector: 'app-product-list',
  standalone: true,
  imports: [CommonModule,FormsModule,ConvertToSpacePipe,StarComponent,RouterLink],
  templateUrl: './product-list.component.html',
  styleUrl: './product-list.component.css'
})
export class ProductListComponent implements OnInit,OnDestroy{
    
    pageTitle: string = 'Product List';
    imageWidth:number = 50;
    imageMargin:number = 2;
    showImage : boolean = false;
    products:IProduct[] = [];
    private _listFilter:string = '';
    private service = inject(ProductService);
    private activeRoute = inject(ActivatedRoute);
    private sub:Subscription;
    errorMessage:string = '';

    get listFilter(){
      return this._listFilter;
    }
    set listFilter(value:string){
     this._listFilter = value;
     this.filteredProducts = (this._listFilter) ? this.performedFilter(value) : this.products;
    }

    filteredProducts:IProduct[] = [];
   
    ngOnInit(): void {
        this.sub =  this.service.getProducts()
                      .subscribe({
                        next:(result:IProduct[])=>{
                          this.products = result;
                          this.filteredProducts = this.products;
                        },
                        error:err=>{
                            console.log(err);
                            
                        }
                      })
        this.sub = this.activeRoute.data.subscribe(data=>{
                  const resolvedData = data["productListData"];
                  this.errorMessage = resolvedData.error;
                  this.onProductsResolved(resolvedData.products);
        })
          
    }
    onProductsResolved(products:IProduct[]){
          this.products = products
          this.filteredProducts = products;
    }
    toggleImage():void {
        this.showImage = ! this.showImage;
    }
    performedFilter(filterBy:string):IProduct[]{
        filterBy = filterBy.toLocaleLowerCase();
        return this.products.filter((product:IProduct)=>product.productName.toLocaleLowerCase().includes(filterBy))
    }
    getInputFromChild(message:string){
      this.pageTitle = `Product List: ${message}`;
    }
    ngOnDestroy(): void {
      this.sub?.unsubscribe();
    }
   
}
