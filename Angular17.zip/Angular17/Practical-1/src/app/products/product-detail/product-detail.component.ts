import { Component, OnDestroy, OnInit, inject } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { IProduct } from '../Model/product';
import { ProductService } from '../service/product.service';
import { Subscription } from 'rxjs';
import { StarComponent } from '../../Shared/star/star.component';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-product-detail',
  standalone: true,
  imports: [StarComponent,CommonModule,RouterLink],
  templateUrl: './product-detail.component.html',
  styleUrl: './product-detail.component.css'
})
export class ProductDetailComponent implements OnInit,OnDestroy{
    pageTitle:string = 'Product Detail';
    product:IProduct;
    errorMessage:string = '';
    private activeRouter:ActivatedRoute = inject(ActivatedRoute);
    private service:ProductService = inject(ProductService);
    private getProductSub$:Subscription;

    ngOnInit(): void {
        this.activeRouter.paramMap.subscribe(param=>{
            const id = Number(param.get('id'));
            this.getProduct(id);
        })
    }
    getProduct(id:number){
        this.getProductSub$ = this.activeRouter.data.subscribe(data=>{
                                    const resolvedData = data['productData'];
                                    this.errorMessage = resolvedData.error;
                                    this.onPrdouctResolved(resolvedData.product);
                                })
    }
    onPrdouctResolved(product:IProduct){
        this.product = product;
    }
    ngOnDestroy(): void {
     this.getProductSub$.unsubscribe();
    }
}
