import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable, catchError, map, tap, throwError } from 'rxjs';
import { IProduct } from '../Model/product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private baseUrl:string = 'api/products';
  private http = inject(HttpClient);
  getProducts():Observable<IProduct[]>{
    return this.http.get<IProduct[]>(this.baseUrl)
                    .pipe(
                      tap(data=>console.log(data)),
                      catchError(this.handelError)
                    );
  }
  getProduct(id:number):Observable<IProduct>{
    return this.http.get<IProduct>(`${this.baseUrl}/${id}`)
                    .pipe(
                      tap(data=>console.log(data)),
                      catchError(this.handelError)
                    );
  }
  private handelError(err : HttpErrorResponse):Observable<never>{
    let errorMessage:string = '';
    if(err.error instanceof ErrorEvent){
      errorMessage = `An error occured: ${err.error.message}`;
    }
    else{
      errorMessage = `Server returned code: ${err.status}, error message is:${err.error.message}`;
    }
    return throwError(()=>errorMessage);
  }

}
