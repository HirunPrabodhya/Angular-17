import { Routes } from "@angular/router";
import { ProductListComponent } from "../product-list/product-list.component";
import { productListResolver } from "../resolver/product-list/product-list.resolver";
import { ProductDetailComponent } from "../product-detail/product-detail.component";
import { productGuard } from "../Guard/product.guard";
import { productDetailResolver } from "../resolver/product-detail/product-detail.resolver";
import { ProductEditComponent } from "../product-edit/product-edit.component";

export const PRODUCT_ROUTES: Routes = [
    {
        path:'',
        component:ProductListComponent,
        resolve:{productListData:productListResolver}
    },
    {
        path:':id',
        component:ProductDetailComponent,
        canActivate:[productGuard],
        resolve:{productData:productDetailResolver}
    },
    {
        path:':id/edit',
        component:ProductEditComponent
    }
];
