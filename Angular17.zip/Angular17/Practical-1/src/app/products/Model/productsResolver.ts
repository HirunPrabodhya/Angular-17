import { IProduct } from "./product";

export interface ProductsResolved{
    products:IProduct[] | [];
    error:string | '';
}