import { IProduct } from "./product";

export interface ProductResolved{
    product:IProduct | null;
    error:string | '';
}