import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-star',
  standalone: true,
  imports: [],
  templateUrl: './star.component.html',
  styleUrl: './star.component.css'
})
export class StarComponent implements OnChanges{
  @Input()rating:number = 0;
  @Output() ratingClick:EventEmitter<string> = new EventEmitter<string>();  
  cropWidth:number = 75;

  ngOnChanges(): void {
    this.cropWidth = this.rating * 75 / 5;
  }
  onClick():void{
      this.ratingClick.emit(`The rating ${this.rating} was clicked!`);
  }

}
